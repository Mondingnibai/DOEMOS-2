<template>
    <div class="ourschool-view">
        <div class="site-section">
            <div class="container">
                <div class="row mb-5">
                    <div class="col-lg-6 mb-lg-0 mb-4">
                        <img src="images/deoms_logo.jpg" alt="Image" class="img-fluid"> 
                    </div>
                    <div class="col-lg-5 ml-auto align-self-center">
                        <h2 class="section-title-underline mb-5">
                            <span>History of Don Emilio Osmena Memorial School</span>
                        </h2>
                        <p>
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's 
                            standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a 
                            type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting.
                        </p>

                        <p>
                            It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop 
                            publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                        </p>
                    </div>
                </div>
    
                <div class="row">
                        <div class="col-lg-6 order-1 order-lg-2 mb-4 mb-lg-0">
                            <img src="images/deoms_logo.jpg" alt="Image" class="img-fluid"> 
                        </div>
                        <div class="col-lg-5 mr-auto align-self-center order-2 order-lg-1">
                            <h2 class="section-title-underline mb-5">
                                <span>School Mission</span>
                            </h2>
                            <ol class="ul-check primary list-unstyled">
                                <li>It is the mission of every school official to handle student problems lightly.</li>
                                <li>Give adjustments to every student's problem and difficulty.</li>
                                <li>Protect Student Rights.</li>
                                <li>Guide students to achieve the highest degree of morale.</li>  
                                <li>Eliminate illiteracy through special modular lessons.</li>
                                <li>It is the mission of the school to produce quanlity mentors who could keep uplifting student academic performance.</li>
                                <li>As stewards of the institution, it is duty of stakeholders, parents, and mentors to engage in shared values responsible for lifelong learning eliminating community illeteracy.</li>  
                            </ol>

                            <h2 class="section-title-underline mb-5">
                                <span>School Vision</span>
                            </h2>
                            <ol class="ul-check primary list-unstyled">
                                <li>It is the vision of the administration faculty, student body, parents and stakeholders adopt protocols to maintain healthy academic and physical stability of the clients.</li>
                                <li>The education in this era continues for the benefit of our young.</li>
                                <li>The mentors should possess the ability ready to cope with the present environment situation.</li>
                            </ol>
                        </div> 
                    </div>
            </div>
        </div>
    </div>
</template>