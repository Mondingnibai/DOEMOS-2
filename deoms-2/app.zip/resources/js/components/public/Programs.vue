<template>  
    <div class="programs-view">
        <div class="site-section">
            <div class="container">
                <div class="row mb-5">
                    <div class="col-lg-6 mb-lg-0 mb-4">
                        <img src="images/deoms_logo.jpg" alt="Image" class="img-fluid"> 
                    </div>
                    <div class="col-lg-5 ml-auto align-self-center">
                        <h2 class="section-title-underline mb-5">
                            <span>Basic Education Department</span>
                        </h2>

                        <ol class="ul-check primary list-unstyled">
                            <li>Nursery</li>
                            <li>Kinder 1</li>
                            <li>Kinder 2</li>
                            <li>Grade 1</li>
                            <li>Grade 2</li>
                            <li>Grade 3</li>
                            <li>Grade 4</li>
                            <li>Grade 5</li>
                            <li>Grade 6</li>
                        </ol>
    
                    </div>
                </div>
    
                <div class="row">
                        <div class="col-lg-6 order-1 order-lg-2 mb-4 mb-lg-0">
                            <img src="images/deoms_logo.jpg" alt="Image" class="img-fluid"> 
                        </div>
                        <div class="col-lg-5 mr-auto align-self-center order-2 order-lg-1">
                            <h2 class="section-title-underline mb-5">
                                <span>Junior High School Department</span>
                            </h2>
                            <ol class="ul-check primary list-unstyled">
                                <li>Grade 7</li>
                                <li>Grade 8</li>
                                <li>Grade 9</li>
                                <li>Grade 10</li>  
                            </ol>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</template>