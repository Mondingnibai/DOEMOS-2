<template>
    <p>This is the homepage</p>
  </template>