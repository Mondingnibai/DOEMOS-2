@extends('layouts.app')

@section('pageTitle', 'Programs')
@section('page-title', 'Programs')
@section('page_desc', 'Below are the following programs we offered')
@section('content')
<programs></programs>
@endsection

