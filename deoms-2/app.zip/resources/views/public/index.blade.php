@extends('layouts.app')

@section('pageTitle', 'Home')
@section('content')
<app></app>
@endsection