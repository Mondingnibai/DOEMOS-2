@extends('layouts.app')

@section('pageTitle', 'Contact Us')
@section('page-title', 'Contact Us')
@section('page_desc', 'Send your comments and feedbacks. Thank you')
@section('content')
<contact></contact>
@endsection
