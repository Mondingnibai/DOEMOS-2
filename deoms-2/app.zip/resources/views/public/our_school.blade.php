@extends('layouts.app')

@section('pageTitle', 'Our School')
@section('page-title', 'Our School')
@section('page_desc', 'History of Don Emilio and Mission/Vision')
@section('content')
<ourschool></ourschool>
@endsection