@extends('layouts.admin')

@section('page-title', 'DEOMS | Forms')
@section('pageTitle', 'Resources')

@section('content')
    <admin-form></admin-form>
@endsection