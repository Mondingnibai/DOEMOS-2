@extends('layouts.admin')

@section('page-title', 'DEOMS | Edit Announcement')
@section('pageTitle', 'Edit Announcement')

@section('content')
<editannouncement></editannouncement>
@endsection