@extends('layouts.admin')

@section('page-title', 'DEOMS | Add Announcement')
@section('pageTitle', 'Add Announcement')

@section('content')
<newannouncement></newannouncement>
@endsection