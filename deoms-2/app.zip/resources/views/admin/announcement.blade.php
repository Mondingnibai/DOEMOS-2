@extends('layouts.admin')

@section('page-title', 'DEOMS | Announcement')
@section('pageTitle', 'List of All Announcement')

@section('content')
<announcement></announcement>
@endsection