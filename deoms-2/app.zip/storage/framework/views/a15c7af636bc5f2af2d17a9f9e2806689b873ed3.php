

<?php $__env->startSection('page-title', 'DEOMS | Edit Announcement'); ?>
<?php $__env->startSection('pageTitle', 'Edit Announcement'); ?>

<?php $__env->startSection('content'); ?>
<editannouncement></editannouncement>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Reymond Bolambao\Documents\Training\DOEMOS-2\deoms-2\resources\views/admin/announcement/edit-announcement.blade.php ENDPATH**/ ?>