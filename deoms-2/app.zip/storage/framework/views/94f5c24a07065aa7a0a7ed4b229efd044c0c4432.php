

<?php $__env->startSection('pageTitle', 'Programs'); ?>
<?php $__env->startSection('page-title', 'Programs'); ?>
<?php $__env->startSection('page_desc', 'Below are the following programs we offered'); ?>
<?php $__env->startSection('content'); ?>
<programs></programs>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Reymond Bolambao\Documents\Training\DOEMOS-2\deoms-2\resources\views/public/programs.blade.php ENDPATH**/ ?>