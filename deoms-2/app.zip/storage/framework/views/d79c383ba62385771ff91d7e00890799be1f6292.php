<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0"><?php echo $__env->yieldContent('pageTitle'); ?></h1>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Reymond Bolambao\Documents\Training\DOEMOS-2\deoms-2\resources\views/layouts/admin/title.blade.php ENDPATH**/ ?>