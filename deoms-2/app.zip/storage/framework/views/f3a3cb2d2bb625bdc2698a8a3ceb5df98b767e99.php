

<?php $__env->startSection('page-title', 'DEOMS::New Announcement'); ?>
<?php $__env->startSection('pageTitle', ''); ?>

<?php $__env->startSection('content'); ?>
<new-announcement></new-announcement>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Reymond Bolambao\Documents\Training\DOEMOS-2\deoms-2\resources\views/admin/announcement/newAnnouncement.blade.php ENDPATH**/ ?>