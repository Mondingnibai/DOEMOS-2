

<?php $__env->startSection('page-title', 'DEOMS | Add Announcement'); ?>
<?php $__env->startSection('pageTitle', 'Add Announcement'); ?>

<?php $__env->startSection('content'); ?>
<newannouncement></newannouncement>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Reymond Bolambao\Documents\Training\DOEMOS-2\deoms-2\resources\views/admin/announcement/add-announcement.blade.php ENDPATH**/ ?>