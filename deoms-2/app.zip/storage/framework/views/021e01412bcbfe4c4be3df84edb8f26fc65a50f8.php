

<?php $__env->startSection('page-title', 'DEOMS | Dashboard'); ?>
<?php $__env->startSection('pageTitle', ''); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto">
    <div class="col-lg-12">
        <div class="row">
            <img src="<?php echo e(asset('images/page_logo.png')); ?>" alt="DEOMS school Logo" class="mx-auto"/>
        </div>
        <div class="row">
            <p class="text-center mx-auto font-weight-bold">Don Emelio Osmena Memorial School, Inc.</p>
        </div>
    </div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Reymond Bolambao\Documents\Training\DOEMOS-2\deoms-2\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>