

<?php $__env->startSection('pageTitle', 'Contact Us'); ?>
<?php $__env->startSection('page-title', 'Contact Us'); ?>
<?php $__env->startSection('page_desc', 'Send your comments and feedbacks. Thank you'); ?>
<?php $__env->startSection('content'); ?>
<contact></contact>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Reymond Bolambao\Documents\Training\DOEMOS-2\deoms-2\resources\views/public/contact.blade.php ENDPATH**/ ?>