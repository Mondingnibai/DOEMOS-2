<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" value="<?php echo e(csrf_token()); ?>"/>
  <link rel="shortcut icon" type="image/x-png" href="<?php echo e(asset('images/favicon.png')); ?>">
  <title><?php echo $__env->yieldContent('page-title'); ?></title>

  
  <!-- Scripts -->
  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">

  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo e(asset('vendor/plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('vendor/dist/css/adminlte.min.css')); ?>">
  <!-- daterange picker css -->
  <link rel="stylesheet" href="<?php echo e(asset('vendor/plugins/daterangepicker/daterangepicker.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('vendor/plugins/dropzone/min/dropzone.css')); ?>">
</head> 
<body class="hold-transition sidebar-mini">
  <div class="wrapper">

    <!-- Top Menu -->
    <?php echo $__env->make('layouts.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Left Menu --> 
    <?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="content-wrapper">
     
      <?php echo $__env->make('layouts.admin.title', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="content">
        <div class="container-fluid">
          <div id="app">
            <?php echo $__env->yieldContent('content'); ?>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer --> 
    <?php echo $__env->make('layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
  <!-- ./wrapper -->
<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="<?php echo e(asset('vendor/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- date range picker --> 
<script src="<?php echo e(asset('vendor/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/plugins/dropzone/min/dropzone.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('vendor/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('vendor/dist/js/adminlte.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\Reymond Bolambao\Documents\Training\DOEMOS-2\deoms-2\resources\views/layouts/admin.blade.php ENDPATH**/ ?>